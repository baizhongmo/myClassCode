﻿using UnityEngine;
using System.Collections;

public static class GameData  {

    public static float x=0;
    public static float y=0;

}
