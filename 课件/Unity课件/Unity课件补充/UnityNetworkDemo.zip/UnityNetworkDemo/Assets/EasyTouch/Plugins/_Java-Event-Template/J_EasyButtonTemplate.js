// EasyButton v1.0 (April 2013)
// EasyButton library is copyright (c) of Hedgehog Team
// Please send feedback or bug reports to the.hedgehog.team@gmail.com

#pragma strict
/*
function On_ButtonUp (buttonName:String){}

function On_ButtonPress (buttonName:String ){}

function On_ButtonDown (buttonName:String ){}
*/
