**********************************************
				EASYTOUCH 
				
Copyright © 2012-2013 THedgehog Team
http://www.blitz3dfr.com/teamtalk/index.php

		the.hedgehog.team@gmail.com

**********************************************

Thank you for your purchase!

If you have any questions, suggestions, please
use the Hedgehog Team Community forum,  here: http://www.blitz3dfr.com/teamtalk/index.php

Or send us an email at : the.hedgehog.team@gmail.com


For classes documentation go to
http://www.blitz3dfr.com/Doc/ET3 


If you like EasyTouch, don't forget a write a review on the asset store :-)